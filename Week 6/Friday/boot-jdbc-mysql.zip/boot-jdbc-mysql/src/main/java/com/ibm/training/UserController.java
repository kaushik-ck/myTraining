package com.ibm.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class UserController {

	@Autowired
	UserService service;

	@RequestMapping("/users")
	List<User> getUsers() {
		return service.getUsers();
	}

	@RequestMapping("/users/{id}")
	User getUserById(@PathVariable long id) {
		return service.getUserById(id);
	}

	@PostMapping("/users")
	void addUser(@RequestBody User user) {
		service.addUser(user);
	}
	
	@PutMapping("users/{id}")
    void updateUser(@PathVariable long id, @RequestBody User user) {
		service.updateUser(id, user);
    }
	
	@DeleteMapping("/users/{id}")
	void deleteUser(@PathVariable long id) {
		service.deleteUser(id);
	}

}
