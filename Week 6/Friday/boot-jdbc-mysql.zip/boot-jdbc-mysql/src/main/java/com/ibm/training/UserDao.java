package com.ibm.training;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

@Repository
public class UserDao {

	@Autowired
	JdbcTemplate template;

	public List<User> getUsers() {
		
		String query = "Select * from userDetails";
		
		List<User> list = template.query(query, new UserMapper());
		return list;
		
	}

	public User getUserById(long userPhoneNumber) {

		String query = "Select * from userDetails where userPhoneNumber=?";

		return template.queryForObject(query, new Object[] { userPhoneNumber }, new UserMapper());

	}
	
	public void addUser(User user) {
		
		String query = "insert into userDetails values(?,?,?,?,?)";
		
		template.update(query, new Object[] {user.getUserName(), user.getUserPassword(), user.getUserId(), 0,0});
		
	}
	

	public void updateUser(long id, User user) {

		String updateQuery = "UPDATE userDetails SET userName=?, userPassword=? WHERE userPhoneNumber = ?";
		
		template.update(updateQuery, new Object[] { user.getUserName(), user.getUserPassword(), id});
	}
		
	

	class UserMapper implements RowMapper<User> {

		@Override
		public User mapRow(ResultSet rs, int rowNum) throws SQLException {

			User user = new User();
			
			user.setUserId(rs.getLong("userPhoneNumber"));
			user.setUserName(rs.getString("userName"));
			user.setUserPassword(rs.getString("userPassword"));
			return user;
		}
	}



	public void deleteUser(long id) {
		
		String query = "Delete from userDetails where userPhoneNumber = ?";
		
		template.update(query, new Object[] {id});
		
	}

}