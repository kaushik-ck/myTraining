package com.ibm.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

	@Autowired
	UserDao dao;

	public List<User> getUsers(){
		return dao.getUsers();
	}

	public User getUserById(long id) {
		return dao.getUserById(id);
	}

	public void addUser(User user) {
		dao.addUser(user);
		
	}

	public void updateUser(long id, User user) {
		dao.updateUser(id, user);
	}

	public void deleteUser(long id) {
		dao.deleteUser(id);	
	}
	
}
